﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class JsonDateTmp
{
    private string unitCode;

    public string UnitCode
    {
        get { return unitCode; }
        set { unitCode = value; }
    }


    private string unitName;

    public string UnitName
    {
        get { return unitName; }
        set { unitName = value; }
    }
}
