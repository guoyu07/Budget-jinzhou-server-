﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Ext.Net;

public partial class test : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        //int i = 0;
        //Literal lt = new Literal();
        //lt.Text = "&nbsp;";
        //foreach (var ic in Enum.GetValues(typeof(Icon)))
        //{
        //    Ext.Net.Button bt = new Ext.Net.Button();
        //    i++;
        //    bt.ID = "ID" + i.ToString();
        //    bt.Text = Enum.GetName(typeof(Icon), ic);
        //    bt.Icon = (Icon)ic;
        //    bt.Style.Add("float", "left");
            
        //    ph.Controls.Add(bt);
        //    ph.Controls.Add(lt);
        //}
        
        
        //GetName(typeof(eErrorDetailCode), myCode);//
    }
}